-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.13 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.3.0.5107
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица taskManager.forTest
CREATE TABLE IF NOT EXISTS `forTest` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT '0',
  `date` bigint(15) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы taskManager.forTest: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `forTest` DISABLE KEYS */;
REPLACE INTO `forTest` (`ID`, `title`, `date`) VALUES
	(2, 'бла бла', 1482091050),
	(3, 'бла бла 2', 1482091240);
/*!40000 ALTER TABLE `forTest` ENABLE KEYS */;

-- Дамп структуры для таблица taskManager.task
CREATE TABLE IF NOT EXISTS `task` (
  `ID` int(6) NOT NULL AUTO_INCREMENT,
  `from_user_id` int(6) NOT NULL DEFAULT '0',
  `for_user_id` int(6) NOT NULL DEFAULT '0',
  `date_created` bigint(15) NOT NULL DEFAULT '0',
  `date_deadline` bigint(15) NOT NULL DEFAULT '0',
  `date_finished` bigint(15) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`ID`),
  KEY `FK_task_users` (`from_user_id`),
  KEY `FK_task_users_2` (`for_user_id`),
  CONSTRAINT `FK_task_users` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`ID`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_task_users_2` FOREIGN KEY (`for_user_id`) REFERENCES `users` (`ID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы taskManager.task: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
/*!40000 ALTER TABLE `task` ENABLE KEYS */;

-- Дамп структуры для таблица taskManager.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(7) NOT NULL AUTO_INCREMENT,
  `date` bigint(15) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT '0',
  `pass` varchar(255) NOT NULL DEFAULT '0',
  `confirm_email` int(2) NOT NULL DEFAULT '0',
  `token` varchar(255) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы taskManager.users: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`ID`, `date`, `email`, `pass`, `confirm_email`, `token`) VALUES
	(15, 1482267186, 'sht_job@ukr.net', '$2y$10$scul9cD2HViJX.fc/.ZQVe55mDoS2TuuchQlgEB2.m1EZYB/miFve', 1, 'b3c4caee582b7f9d0bfbd3d2d64589af'),
	(18, 1482326819, 'sht_66job@ukr.net', '$2y$10$vhKUmKONtkQPEkkulwo76eELpYUwZN63HPKz85co8aLPJJobi//vi', 1, '8fce79fb8cecc1d56473e7565f4283c2');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
